# NEXVY — site inicial

## Como abrir
1. Extraia o ZIP.
2. Abra a pasta no VS Code.
3. Abra `index.html` no navegador ou use a extensão Live Server.

## Onde editar produtos e preços
Abra:
`js/products.js`

Cada produto possui:
- `name`: nome
- `category`: categoria
- `description`: descrição
- `price`: preço. Use um número, por exemplo `19.90`.

Atualmente os preços estão como `0`, então o site mostra "Consultar". Isso evita inventar preços que você ainda não informou.

## Discord
O link usado no site é:
https://discord.gg/jXRWPKA7k

## Próximas integrações recomendadas
Este é um front-end funcional/protótipo. Para vender de verdade, ainda será necessário integrar:
- gateway de pagamento;
- backend/banco de dados;
- estoque;
- criação e acompanhamento de pedidos;
- autenticação, se desejada;
- cálculo/gestão de entrega quando aplicável;
- painel administrativo.

Não coloque chaves secretas ou credenciais de pagamento no JavaScript do navegador.


## Preços
Todos os preços ficam centralizados no arquivo `js/products.js`.

Procure por:
`price: 0`

e substitua por, por exemplo:
`price: 24.90`

Se deixar `price: 0`, o site continuará mostrando **Consultar**.
