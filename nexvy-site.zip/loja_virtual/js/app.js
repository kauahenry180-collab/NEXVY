const state={filter:"Todos",query:"",cart:[]};
const money=v=>v===0?"Consultar":new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(v);
const $=s=>document.querySelector(s);

function productVisual(p){return `<div class="product-visual"><div class="visual-glow"></div><span class="product-symbol">${p.icon}</span></div>`}
function renderCategories(){
  $("#categoryGrid").innerHTML=CATEGORIES.map(c=>`<button class="category-card" onclick="setFilter('${c.name}')"><span class="category-icon">${c.icon}</span><div><h3>${c.name}</h3><p>${c.desc}</p></div><span class="arrow">→</span></button>`).join("");
}
function renderProducts(){
  const q=state.query.toLowerCase();
  const list=PRODUCTS.filter(p=>(state.filter==="Todos"||p.category===state.filter)&&(!q||`${p.name} ${p.category}`.toLowerCase().includes(q)));
  $("#productGrid").innerHTML=list.length?list.map(p=>`
    <article class="product-card">
      ${productVisual(p)}
      <div class="product-body">
        <div class="product-meta"><span>${p.category}</span>${p.tag?`<b>${p.tag}</b>`:""}</div>
        <h3>${p.name}</h3><p>${p.description}</p>
        <div class="product-bottom"><strong>${money(p.price)}</strong><button class="small-btn" onclick="addToCart('${p.id}')">Adicionar</button></div>
        <button class="details" onclick="openProduct('${p.id}')">Ver detalhes →</button>
      </div>
    </article>`).join(""):`<div class="empty">Nenhum produto encontrado.</div>`;
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter===state.filter));
}
function setFilter(f){state.filter=f;renderProducts();document.querySelector("#produtos").scrollIntoView({behavior:"smooth"});}
function addToCart(id){const p=PRODUCTS.find(x=>x.id===id);const item=state.cart.find(x=>x.id===id);if(item)item.qty++;else state.cart.push({id,qty:1});renderCart();openCart();}
function removeFromCart(id){state.cart=state.cart.filter(x=>x.id!==id);renderCart();}
function renderCart(){
  const totalItems=state.cart.reduce((s,x)=>s+x.qty,0);$("#cartCount").textContent=totalItems;
  $("#cartItems").innerHTML=state.cart.length?state.cart.map(x=>{const p=PRODUCTS.find(y=>y.id===x.id);return `<div class="cart-item">${productVisual(p)}<div><b>${p.name}</b><small>${x.qty} × ${money(p.price)}</small><button onclick="removeFromCart('${p.id}')">Remover</button></div></div>`}).join(""):`<div class="empty cart-empty"><span>🛒</span><h3>Seu carrinho está vazio</h3><p>Adicione produtos para começar.</p></div>`;
  const total=state.cart.reduce((s,x)=>s+(PRODUCTS.find(p=>p.id===x.id).price*x.qty),0);$("#cartTotal").textContent=total?money(total):"Consultar";
}
function openCart(){document.body.classList.add("drawer-open")}
function closeCart(){document.body.classList.remove("drawer-open")}
function openProduct(id){
 const p=PRODUCTS.find(x=>x.id===id);
 $("#modalContent").innerHTML=`<div class="modal-product">${productVisual(p)}<div><span class="eyebrow">${p.category}</span><h2>${p.name}</h2><p>${p.description}</p><div class="modal-price">${money(p.price)}</div><button class="btn primary" onclick="addToCart('${p.id}');closeModal()">Adicionar ao carrinho</button><a class="discord-link" href="https://discord.gg/jXRWPKA7k" target="_blank">Dúvidas? Fale no Discord ↗</a></div></div>`;
 $("#productModal").classList.add("show");
}
function closeModal(){$("#productModal").classList.remove("show")}
function checkout(){
  if(!state.cart.length)return;
  const names=state.cart.map(x=>{const p=PRODUCTS.find(y=>y.id===x.id);return `${x.qty}x ${p.name}`}).join(", ");
  const msg=encodeURIComponent(`Olá! Quero atendimento sobre meu pedido na loja. Produtos: ${names}`);
  window.open(`https://discord.gg/jXRWPKA7k?order=${msg}`,"_blank");
}
document.addEventListener("DOMContentLoaded",()=>{
 renderCategories();renderProducts();renderCart();
 document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>setFilter(b.dataset.filter)));
 $("#cartBtn").onclick=openCart;$("#closeCart").onclick=closeCart;$("#backdrop").onclick=closeCart;
 $("#closeModal").onclick=closeModal;$("#productModal").addEventListener("click",e=>{if(e.target.id==="productModal")closeModal()});
 $("#checkoutBtn").onclick=checkout;
 $("#searchBtn").onclick=()=>{ $("#searchOverlay").classList.add("show");$("#searchInput").focus()};
 $("#closeSearch").onclick=()=>$("#searchOverlay").classList.remove("show");
 $("#searchInput").addEventListener("input",e=>{state.query=e.target.value;renderProducts()});
});
