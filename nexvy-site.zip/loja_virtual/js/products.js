/*
 * ============================
 * PREÇOS DA NEXVY
 * ============================
 * Edite somente o campo `price` de cada produto.
 * Exemplo: price: 19.90
 *
 * Se price ficar 0, o site mostra "Consultar".
 */
const PRODUCTS = [
  {id:"nitro",name:"Discord Nitro",category:"Discord",icon:"💜",tag:"Popular",description:"Assinatura Nitro para Discord. Consulte a modalidade e disponibilidade no suporte.",price:0},
  {id:"boost",name:"Impulsos para Discord",category:"Discord",icon:"🚀",tag:"Discord",description:"Impulsos para servidor Discord. Quantidade e duração conforme a opção escolhida.",price:0},
  {id:"discord-members",name:"Membros para Discord",category:"Discord",icon:"👥",description:"Serviço de membros para Discord. Consulte condições antes da compra.",price:0},
  {id:"steam",name:"Steam Key",category:"Games",icon:"🎮",tag:"Games",description:"Keys digitais para jogos da Steam. O título e a região devem ser confirmados antes da compra.",price:0},
  {id:"robux",name:"Robux",category:"Games",icon:"🟩",tag:"Popular",description:"Créditos Robux para Roblox. Consulte o pacote disponível.",price:0},
  {id:"hbo",name:"HBO Max",category:"Streaming",icon:"▶",description:"Serviço digital de streaming. Modalidade e período conforme disponibilidade.",price:0},
  {id:"netflix",name:"Netflix",category:"Streaming",icon:"N",description:"Serviço digital de streaming. Modalidade e período conforme disponibilidade.",price:0},
  {id:"crunchyroll",name:"Crunchyroll",category:"Streaming",icon:"🍥",description:"Serviço de streaming de anime. Modalidade e período conforme disponibilidade.",price:0},
  {id:"disney",name:"Disney+",category:"Streaming",icon:"✦",description:"Serviço digital de streaming. Modalidade e período conforme disponibilidade.",price:0},
  {id:"streaming-other",name:"Outros Streaming",category:"Streaming",icon:"📺",description:"Consulte outros serviços de streaming disponíveis.",price:0},
  {id:"canva",name:"Canva Pro",category:"Ferramentas",icon:"C",tag:"Pro",description:"Acesso a recursos Pro do Canva conforme modalidade oferecida.",price:0},
  {id:"chatgpt",name:"ChatGPT Pro",category:"Ferramentas",icon:"AI",tag:"Pro",description:"Produto digital relacionado ao ChatGPT. Consulte modalidade, condições e disponibilidade.",price:0},
  {id:"capcut",name:"CapCut Pro",category:"Ferramentas",icon:"✂",tag:"Pro",description:"Acesso a recursos Pro do CapCut conforme modalidade oferecida.",price:0},
  {id:"spotify-1m",name:"Spotify Premium — 1 mês",category:"Streaming",icon:"♫",description:"Plano de 1 mês. Condições conforme a oferta vigente.",price:0},
  {id:"spotify-3m",name:"Spotify Premium — 3 meses",category:"Streaming",icon:"♫",description:"Plano de 3 meses. Condições conforme a oferta vigente.",price:0},
  {id:"spotify-eterno",name:"Spotify Premium — Eterno",category:"Streaming",icon:"♫",tag:"Destaque",description:"Oferta de acesso com modalidade descrita como “eterno”. Confirme condições e disponibilidade no suporte.",price:0},
  {id:"ig-followers",name:"Instagram — Seguidores",category:"Redes Sociais",icon:"◎",description:"Serviço para seguidores. Quantidade e condições devem ser escolhidas no atendimento.",price:0},
  {id:"ig-likes",name:"Instagram — Curtidas",category:"Redes Sociais",icon:"♥",description:"Serviço para curtidas em conteúdo. Consulte quantidade e condições.",price:0},
  {id:"ig-views",name:"Instagram — Visualizações",category:"Redes Sociais",icon:"◉",description:"Serviço de visualizações. Consulte quantidade e condições.",price:0},
  {id:"ig-reposts",name:"Instagram — Reposts",category:"Redes Sociais",icon:"↻",description:"Serviço de reposts. Consulte quantidade e condições.",price:0},
  {id:"tiktok-followers",name:"TikTok — Seguidores",category:"Redes Sociais",icon:"♪",description:"Serviço para seguidores. Consulte quantidade e condições.",price:0},
  {id:"tiktok-likes",name:"TikTok — Curtidas",category:"Redes Sociais",icon:"♥",description:"Serviço para curtidas. Consulte quantidade e condições.",price:0},
  {id:"tiktok-views",name:"TikTok — Visualizações",category:"Redes Sociais",icon:"◉",description:"Serviço de visualizações. Consulte quantidade e condições.",price:0},
  {id:"tiktok-reposts",name:"TikTok — Reposts",category:"Redes Sociais",icon:"↻",description:"Serviço de reposts. Consulte quantidade e condições.",price:0},
  {id:"youtube-followers",name:"YouTube — Inscritos",category:"Redes Sociais",icon:"▶",description:"Serviço relacionado a inscritos. Consulte quantidade e condições.",price:0},
  {id:"youtube-likes",name:"YouTube — Curtidas",category:"Redes Sociais",icon:"♥",description:"Serviço relacionado a curtidas. Consulte quantidade e condições.",price:0},
  {id:"youtube-views",name:"YouTube — Visualizações",category:"Redes Sociais",icon:"◉",description:"Serviço relacionado a visualizações. Consulte quantidade e condições.",price:0},
  {id:"youtube-reposts",name:"YouTube — Reposts",category:"Redes Sociais",icon:"↻",description:"Serviço relacionado a compartilhamentos/reposts. Consulte quantidade e condições.",price:0},
  {id:"facebook-followers",name:"Facebook — Seguidores",category:"Redes Sociais",icon:"f",description:"Serviço para seguidores. Consulte quantidade e condições.",price:0},
  {id:"facebook-likes",name:"Facebook — Curtidas",category:"Redes Sociais",icon:"♥",description:"Serviço para curtidas. Consulte quantidade e condições.",price:0},
  {id:"telegram-members",name:"Telegram — Membros",category:"Telegram",icon:"✈",tag:"Telegram",description:"Serviço para membros em Telegram. Consulte quantidade e condições.",price:0}
];

const CATEGORIES = [
  {name:"Discord",icon:"💬",desc:"Nitro, impulsos e membros"},
  {name:"Games",icon:"🎮",desc:"Steam Keys e Robux"},
  {name:"Streaming",icon:"🎬",desc:"Entretenimento digital"},
  {name:"Ferramentas",icon:"🛠️",desc:"Canva, ChatGPT e CapCut"},
  {name:"Redes Sociais",icon:"📱",desc:"Seguidores, likes e views"},
  {name:"Telegram",icon:"✈️",desc:"Membros para canais e grupos"}
];
